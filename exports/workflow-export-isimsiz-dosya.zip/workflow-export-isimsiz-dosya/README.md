# isimsiz dosya - Docker Export

Ready-to-run Docker export of your KAI-Fusion workflow.

## Quick Start

1. Extract: `unzip workflow-export-isimsiz-dosya.zip && cd workflow-export-isimsiz-dosya/`
2. Start: `docker-compose up -d`
3. Test: `curl http://localhost:8002/health`

## API Usage

Execute workflow:
```bash
curl -X POST http://localhost:8002/api/workflow/execute \
  -H "Content-Type: application/json" \

  -d '{"input": "Your input here"}'
```

## Configuration

- API key required: False
- Port: 8002
- Modify `.env` file to change settings

## Troubleshooting

- Check status: `docker-compose ps`
- View logs: `docker-compose logs workflow-api`
- Restart: `docker-compose restart`

Generated: 2025-08-27 14:26:21
